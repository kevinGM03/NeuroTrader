// Ajustar la altura de los iframe según su contenido
function adjustIframeHeight(iframe) {
    iframe.style.height = iframe.contentWindow.document.body.scrollHeight + "px";
  }
  
  // Ejecutar el ajuste cuando el contenido del iframe esté listo
  document.querySelectorAll("iframe").forEach((iframe) => {
    iframe.addEventListener("load", () => adjustIframeHeight(iframe));
  });
  