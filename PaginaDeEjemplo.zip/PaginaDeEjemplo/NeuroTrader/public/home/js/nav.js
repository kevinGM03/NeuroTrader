document.addEventListener('DOMContentLoaded', function () {
    const menuToggle = document.getElementById('menu-toggle');
    const mobileMenu = document.getElementById('mobile-menu');

    menuToggle.addEventListener('click', function () {
        // Alterna la clase 'hidden' y 'open' en el menú móvil
        mobileMenu.classList.toggle('hidden');
        mobileMenu.classList.toggle('open');  // Añadido para controlar el estado del menú
    });
});
