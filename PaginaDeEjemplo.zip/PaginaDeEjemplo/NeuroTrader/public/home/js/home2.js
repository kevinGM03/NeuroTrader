document.addEventListener("DOMContentLoaded", () => {
    const image = document.querySelector(".dashboard-image");

    // Efecto de aparición al cargar la página
    image.style.opacity = "0";
    image.style.transition = "opacity 1.5s ease-in-out";
    setTimeout(() => {
        image.style.opacity = "1";
    }, 500);
});
