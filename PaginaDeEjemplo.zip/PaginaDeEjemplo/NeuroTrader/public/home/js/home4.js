document.addEventListener("DOMContentLoaded", () => {
    const swiper = new Swiper(".trust-slider", {
        loop: true,
        spaceBetween: 20, // Ajusta el espacio entre slides si es necesario
        pagination: {
            el: ".trust-pagination",
            clickable: true,
        },
        autoplay: {
            delay: 3000,
            disableOnInteraction: false,
        },
        breakpoints: {
            640: {
                slidesPerView: 1,
            },
            768: {
                slidesPerView: 2,
            },
            1024: {
                slidesPerView: 3,
            },
        },
    });
});
