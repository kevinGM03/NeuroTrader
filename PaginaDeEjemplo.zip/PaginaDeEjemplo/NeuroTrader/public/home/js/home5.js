document.addEventListener('DOMContentLoaded', () => {
    const accordionItems = document.querySelectorAll('.accordion-item');
  
    accordionItems.forEach((item) => {
      const header = item.querySelector('.accordion-header');
      const body = item.querySelector('.accordion-body');
      const icon = item.querySelector('.accordion-icon');
  
      header.addEventListener('click', () => {
        const isActive = body.classList.contains('active');
  
        // Close all accordions
        accordionItems.forEach((i) => {
          i.querySelector('.accordion-body').classList.remove('active');
          i.querySelector('.accordion-icon').style.transform = 'rotate(0)';
        });
  
        // Open clicked accordion if it was not active
        if (!isActive) {
          body.classList.add('active');
          icon.style.transform = 'rotate(180deg)';
        }
      });
    });
  });
  