// Función para alternar la visibilidad del dropdown
function toggleDropdown(elementId) {
    const dropdown = document.querySelector(elementId);
    dropdown.classList.toggle('hidden');
}
