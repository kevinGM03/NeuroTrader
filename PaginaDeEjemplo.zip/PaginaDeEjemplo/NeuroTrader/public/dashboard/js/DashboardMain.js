// Por ahora no hay funcionalidad específica, pero aquí puedes agregar la lógica en el futuro
console.log("Dashboard cargado correctamente");
