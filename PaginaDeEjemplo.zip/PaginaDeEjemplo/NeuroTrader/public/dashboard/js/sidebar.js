// Función para navegar entre secciones
function navigateTo(section) {
    console.log('Navigating to', section);
}
