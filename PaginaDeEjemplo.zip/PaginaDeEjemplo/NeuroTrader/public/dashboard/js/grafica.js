// Configuración de opciones para el gráfico de líneas con más espacio vertical
let lineOptions = {
    series: [
        {
            name: "Bitcoin (BTC)",
            data: [23, 40, 22, 27, 13, 22, 37, 21, 44, 22, 30, 45],
        },
        {
            name: "Ethereum(ETH)",
            data: [30, 25, 36, 30, 45, 35, 64, 52, 59, 36, 39, 51],
        },
        {
            name: "Solana(SOL)",
            data: [10, 15, 35, 20, 50, 40, 45, 40, 30, 55, 20, 25],
        },
        {
            name: "Doge(DOGE)",
            data: [60, 40, 50, 65, 45, 35, 55, 75, 70, 60, 65, 55],
        }
    ],
    chart: {
        fontFamily: "Urbanist, sans-serif",
        height: '100%', 
        type: "area",
        background: "transparent",
        toolbar: {
            show: false,
        },
    },
    xaxis: {
        type: "category",
        categories: [
            "14:00", "14:10", "14:20", "14:30", "14:40", "14:50", "14:60",
            "15:00", "15:10", "15:20", "15:30",
        ],
        axisBorder: { show: false },
        axisTicks: { show: false },
        crosshairs: { show: false },
    },
    yaxis: {
        labels: { offsetX: -10 },
        title: { style: { fontSize: "0px" } },
        min: 0,
        max: 75,
        tickAmount: 3,
    },
    colors: ["#FFBB54", "#00A389", "#0096FF", "#FF6347"], 
    fill: {
        colors: ['transparent', 'transparent', 'transparent', 'transparent'],
        type: ['solid', 'solid', 'solid', 'solid'],
    },
    legend: {
        show: true,
        position: "top",
        horizontalAlign: "right",
    },
    stroke: {
        width: [2, 2, 2, 2],
        curve: "straight",
    },
    markers: { show: false },
    labels: { show: false },
    dataLabels: { enabled: false },
    grid: {
        show: true,
        xaxis: { lines: { show: true } },
        yaxis: { lines: { show: true } },
        column: { opacity: 0.2 },
    },
    tooltip: {
        enabled: true,
        custom: function({ series, seriesIndex, dataPointIndex, w }) {
            return `<div class="custom-tooltip">
                        <span class="custom-tooltip__title">${w.globals.series[seriesIndex][dataPointIndex]} Request</span>
                        <span class="custom-tooltip__subtitle"> From ${w.globals.seriesNames[seriesIndex]}</span>
                    </div>`;
        }
    },
    responsive: [
        { breakpoint: 1024, options: { chart: { height: '100%' } } },
        { breakpoint: 1366, options: { chart: { height: '100%' } } },
    ],
};

// Renderizar el gráfico de líneas en el contenedor especificado
let lineChartContainer = document.querySelector("#line-chart");
let lineChart = lineChartContainer && new ApexCharts(lineChartContainer, lineOptions);
lineChart && lineChart.render();
