
function profileAction() {
    var dropdown = document.getElementById("profile-dropdown");
    if (dropdown.style.display === "none" || dropdown.style.display === "") {
        dropdown.style.display = "block";
    } else {
        dropdown.style.display = "none"; 
    }
}


document.addEventListener("click", function(event) {
    var dropdown = document.getElementById("profile-dropdown");
    var avatarContainer = document.querySelector(".avatar-container");

    if (!avatarContainer.contains(event.target) && dropdown.style.display === "block") {
        dropdown.style.display = "none"; 
    }
});
