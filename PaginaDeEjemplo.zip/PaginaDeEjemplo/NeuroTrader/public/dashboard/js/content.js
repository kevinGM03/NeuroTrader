// De momento, no es necesaria ninguna funcionalidad JavaScript.
